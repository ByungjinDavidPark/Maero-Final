package ppp.model;//Author: Luke Eskildsen
//Project: Maero
//Last Edited: 27/09/14
//Desc: report class is used to query database and format output in several ways,
// eg lendingReports etc

public class Report{
	
//All reports can be called by user ppp.model.Admin and Reception only(requires validation userType loop?),
//All reports should follow consistent output format, and let user select time range(Daily, Monthly, Yearly)
//Can add additional reports after

//functions/methods of class ppp.model.Report
	//lendingReport{
	//}//close lendingReport
	
	//fineReport{
	//}//close fineReport
	
	//bookPurchaseReport{
	//}//close bookPurchaseReport
	
}//close ppp.model.Report
