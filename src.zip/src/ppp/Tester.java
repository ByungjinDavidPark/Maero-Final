package ppp;


import ppp.ui.Login;
import javax.swing.*;

/**
 * Created by davidpark on 3/10/14.
 */
public class Tester
{
    public static void main(String[] a)
    {
        Login newLogin = new Login();
        newLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        newLogin.setSize(700,600);
        newLogin.setVisible(true);




    }




}
